<?php
/**
 * @copyright Copyright (c) Aligent Consulting. (http://www.aligent.com.au)
 * @license https://opensource.org/licenses/osl-3.0.php OSL-3.0
 */

namespace EcoBahn\CarbonCalculator\Service;

use RuntimeException;
use UnexpectedValueException;
use Magento\Framework\Api\ExtensibleDataInterface;
use Magento\Framework\Serialize\Serializer\Json as JsonSerializer;
use Psr\Log\LoggerInterface;
use EcoBahn\CarbonCalculator\Api\Data\GeoCoordinateInterface;
use EcoBahn\CarbonCalculator\Api\DistanceCalculatorInterface;
use EcoBahn\CarbonCalculator\Model\GoogleRestApi;
use EcoBahn\CarbonCalculator\Helper\ConfigHelper;

class GoogleDistance implements DistanceCalculatorInterface
{
    const BASE_URL = 'https://maps.googleapis.com/maps/api/distancematrix/json';

    /** @var GoogleRestApi */
    private $googleApi;

    /** @var ConfigHelper */
    private $configHelper;

    /** @var JsonSerializer */
    private $jsonSerializer;

    /** @var LoggerInterface */
    private $logger;

    public function __construct(
        GoogleRestApi $googleApi,
        ConfigHelper $configHelper,
        JsonSerializer $jsonSerializer,
        LoggerInterface $logger
    ) {
        $this->googleApi = $googleApi;
        $this->configHelper = $configHelper;
        $this->jsonSerializer = $jsonSerializer;
        $this->logger = $logger;
    }

    /**
     * @param ExtensibleDataInterface $address
     * @return string
     * @throws UnexpectedValueException
     */
    private function toParam(ExtensibleDataInterface $address)
    {
        if ($address instanceof GeoCoordinateInterface) {
            /** @var GeoCoordinateInterface $address */
            return $address->getLatitude() . ',' . $address->getLongitude();
        }

        $parts = [];
        if ($address->getStreet()) {
            $parts = $address->getStreet();
        }
        $parts = array_filter(array_merge($parts, [
            $address->getCity(),
            $address->getRegionCode(),
            $address->getCountryId(),
            $address->getPostcode()
        ]));
        if (count($parts) == 0) {
            throw new UnexpectedValueException('Unable to convert address param');
        }
        return implode(' ', $parts);
    }

    /**
     * Get the HTTP GET params required for the API request
     * @param ExtensibleDataInterface $start
     * @param ExtensibleDataInterface $end
     * @return string[]
     */
    private function getParams(
        ExtensibleDataInterface $start,
        ExtensibleDataInterface $end
    ) {
        return [
            'origins' => $this->toParam($start),
            'destinations' => $this->toParam($end),
        ];
    }

    /**
     * Calculates distance from point A to point B
     *
     * @see https://developers.google.com/maps/documentation/distance-matrix/intro#DistanceMatrixRequests
     * @param ExtensibleDataInterface $start
     * @param ExtensibleDataInterface $end
     * @return float Distance in kilometres
     */
    public function calculateDistance(
        ExtensibleDataInterface $start,
        ExtensibleDataInterface $end
    ): float {
        $params = $this->getParams($start, $end);
        $params['units'] = 'metric';
        $params['key'] = $this->configHelper->getGeocodeApiKey();

        $response = $this->googleApi->callGoogleApi(static::BASE_URL, 'GET', $params);

        if (isset($response['rows'][0]['elements'][0]['distance']['value'])) {
            $metres = $response['rows'][0]['elements'][0]['distance']['value'];
            return $metres / 1000.0;
        } else {
            $json = $this->jsonSerializer->serialize($response);
            $this->logger->error('Failed to calculate distance; response: ' . $json);
            throw new RuntimeException('Failed to calculate distance');
        }
    }
}
