<?php
/**
 * @copyright Copyright (c) Aligent Consulting. (http://www.aligent.com.au)
 * @license https://opensource.org/licenses/osl-3.0.php OSL-3.0
 */

namespace EcoBahn\CarbonCalculator\Service;

use Psr\Log\LoggerInterface;
use Magento\Sales\Api\Data\ShipmentInterface;
use Magento\Sales\Model\Order\AddressRepository;
use EcoBahn\CarbonCalculator\Api\CarbonCalculatorInterface;
use EcoBahn\CarbonCalculator\Api\Data\GeoCoordinateInterface;
use EcoBahn\CarbonCalculator\Api\Data\GeoCoordinateInterfaceFactory as GeoCoordinateFactory;
use EcoBahn\CarbonCalculator\Api\Data\CarbonCalculatorResultInterface;
use EcoBahn\CarbonCalculator\Api\Data\CarbonCalculatorResultInterfaceFactory as CarbonCalculatorResultFactory;
use EcoBahn\CarbonCalculator\Api\DistanceCalculatorInterface;
use EcoBahn\CarbonCalculator\Api\GeoCodeInterface;
use EcoBahn\CarbonCalculator\Helper\ConfigHelper;
use EcoBahn\CarbonCalculator\Model\ResourceModel\Airport\CollectionFactory as AirportCollectionFactory;
use EcoBahn\CarbonCalculator\Model\ResourceModel\Airport as AirportResource;
use EcoBahn\CarbonCalculator\Model\AirportFactory;
use EcoBahn\CarbonCalculator\Model\Airport;
use EcoBahn\CarbonCalculator\Service\HaversineDistance;

/**
 * Calculates carbon emissions based on up to three transport legs:
 * 1. road (from warehouse to nearest airport)
 * 2. air (from nearest airport to warehouse, to nearest airport to destination)
 * 3. road (from airport to final destination)
 */
class AirportCarbonCalculator implements CarbonCalculatorInterface
{
    /** @var AddressRepository */
    private $addressRepository;

    /** @var ConfigHelper */
    private $configHelper;

    /** @var GeoCoordinateInterfaceFactory */
    private $coordinateFactory;

    /** @var CarbonCalculatorResultFactory */
    private $calculatorResultFactory;

    /** @var GeoCodeInterface */
    private $geoCode;

    /** @var AirportCollectionFactory */
    private $airportCollectionFactory;

    /** @var AirportResource */
    private $airportResource;

    /** @var AirportFactory */
    private $airportFactory;

    /** @var DistanceCalculatorInterface */
    private $distanceCalculator;

    /** @var HaversineDistance */
    private $haversine;

    public function __construct(
        LoggerInterface $logger,
        AddressRepository $addressRepository,
        ConfigHelper $configHelper,
        GeoCoordinateFactory $coordinateFactory,
        CarbonCalculatorResultFactory $calculatorResultFactory,
        GeoCodeInterface $geoCode,
        AirportCollectionFactory $airportCollectionFactory,
        AirportResource $airportResource,
        AirportFactory $airportFactory,
        DistanceCalculatorInterface $distanceCalculator,
        HaversineDistance $haversine
    ) {
        $this->logger = $logger;
        $this->addressRepository = $addressRepository;
        $this->configHelper = $configHelper;
        $this->coordinateFactory = $coordinateFactory;
        $this->calculatorResultFactory = $calculatorResultFactory;
        $this->geoCode = $geoCode;
        $this->airportCollectionFactory = $airportCollectionFactory;
        $this->distanceCalculator = $distanceCalculator;
        $this->airportResource = $airportResource;
        $this->airportFactory = $airportFactory;
        $this->haversine = $haversine;
    }

    public function findClosestAirport(GeoCoordinateInterface $coords, string $country = ''): Airport
    {
        $this->logger->debug(__(
            "Finding closest airport to coords: %1, %2",
            $coords->getLatitude(),
            $coords->getLongitude()
        ));

        /** @var \EcoBahn\CarbonCalculator\Model\ResourceModel\Airport\Collection $collection */
        $collection = $this->airportCollectionFactory->create();
        if ($country) {
            $clause = "(accessible_countries = '' OR accessible_countries LIKE ?)";
            $collection->getSelect()->where($clause, '%,' . $country . ',%');
        }

        $minimumDistance = 50000;
        /** @var Airport $closestAirport */
        $closestAirport = null;
        foreach ($collection as $airport) {
            $haversineDistance = $this->haversine->calculateDistance($coords, $airport->getCoordinates());
            $this->logger->debug(__(
                "Haversine distance to airport %1: %2km",
                $airport->getCode(),
                $haversineDistance
            ));
            if ($haversineDistance < $minimumDistance) {
                $minimumDistance = $haversineDistance;
                $closestAirport = $airport;
            }
        }
        if (!$closestAirport) {
            $this->logger->error('Unable to find nearest airport');
            throw new \RuntimeException(__('Unable to find nearest airport'));
        }

        $this->logger->debug(__(
            "Closest airport: %1 (to coords: %2, %3)",
            $closestAirport->getCode(),
            $coords->getLatitude(),
            $coords->getLongitude()
        ));

        return $closestAirport;
    }

    public function getStartingAirport(): Airport
    {
        static $startingAirport = null;

        if ($startingAirport !== null) {
            return $startingAirport;
        }

        $airportCode = $this->configHelper->getWarehouseAirportCode();
        if ($airportCode) {
            $this->logger->debug(__("Loading warehouse airport: %1", $airportCode));
            $startingAirport = $this->airportFactory->create();
            $this->airportResource->load($startingAirport, $airportCode);
            if (!$startingAirport->getCode()) {
                throw new \DomainException(__("Unable to load airport: %1", $airportCode));
            }
            return $startingAirport;
        }

        $warehouse = $this->configHelper->getWarehouseCoords();

        if ($warehouse) {
            $this->logger->debug(__(
                "Loaded warehouse coordinates: %1, %2",
                $warehouse->getLatitude(),
                $warehouse->getLongitude()
            ));
        } else {
            $this->logger->debug(__("Warehouse coordinates unknown, calculating"));
            $warehouseAddress = $this->configHelper->getWarehouseAddress();
            $warehouse = $this->geoCode->getGeoCoordinateByAddress($warehouseAddress);
            if ($warehouse === null) {
                throw new \RuntimeException("Unable to determine warehouse location");
            }

            // Save warehouse coords to DB
            $this->configHelper->setWarehouseLat($warehouse->getLatitude());
            $this->configHelper->setWarehouseLng($warehouse->getLongitude());
            $this->logger->debug(__(
                "Calulated warehouse coordinates: %1, %2",
                $warehouse->getLatitude(),
                $warehouse->getLongitude()
            ));
        }

        return $this->findClosestAirport($warehouse, $this->configHelper->getWarehouseCountry());
    }

    /**
     * @param ShipmentInterface $shipment
     * @return float
     */
    protected function calculateTotalWeight(ShipmentInterface $shipment): float
    {
        // N.B. $shipment->getTotalWeight() is always null so this has to be done manually
        $weight = 0.0;
        foreach ($shipment->getAllItems() as $item) {
            $weight += $item->getWeight() * $item->getQty();
        }
        return $weight;
    }

    public function calculateShipmentEmissions(ShipmentInterface $shipment): CarbonCalculatorResultInterface
    {
        $shipmentId = $shipment->getEntityId();
        $this->logger->debug(__('Calculating emissions for shipment: %1', $shipmentId));

        $shipmentWeight = $this->calculateTotalWeight($shipment);
        $this->logger->debug(__('Total weight for shipment: %1kg', $shipmentWeight));

        $airEmissionRate = $this->configHelper->getAirEmissions();
        $roadEmissionRate = $this->configHelper->getRoadEmissions();
        if ($airEmissionRate == null || $roadEmissionRate == null) {
            throw new \RuntimeException(__('Missing emission rate data'));
        }

        $warehouse = $this->configHelper->getWarehouseAddress();
        $warehouseAirportDistance = $this->configHelper->getWarehouseAirportDistance();
        /** @var Airport $startingAirport */
        $startingAirport = $this->getStartingAirport();
        if ($warehouseAirportDistance === null) {
            $this->logger->debug(__('Calculating warehouse-airport distance for shipment: %1', $shipmentId));
            $warehouseAirportDistance = $this->distanceCalculator->calculateDistance(
                $warehouse,
                $startingAirport->getCoordinates()
            );
            $this->logger->debug(__("Calculated warehouse-airport distance: %1km", $warehouseAirportDistance));
            $this->configHelper->setWarehouseAirport($startingAirport);
            $this->configHelper->setWarehouseAirportDistance($warehouseAirportDistance);
            $this->configHelper->clean();
        } else {
            $this->logger->debug(__("Fetched warehouse-airport distance: %1km", $warehouseAirportDistance));
        }

        /** @var \Magento\Sales\Model\Order\Address $address */
        $address = $shipment->getShippingAddress();
        $this->logger->debug(__(
            "Shipment %1 being sent to %2 %3, %4",
            $shipmentId,
            $address->getCity(),
            $address->getPostcode(),
            $address->getCountryId()
        ));

        $this->logger->debug(__(
            "Shipment %1 checking air transport route from %2 (country %3 to %4)",
            $shipmentId,
            $startingAirport->getCode(),
            $startingAirport->getCountry(),
            $address->getCountryId()
        ));

        $finalAirport = null;
        $onlyRoadFreight = false;
        if ($startingAirport->getServicesDomestic() || $startingAirport->getCountry() != $address->getCountryId()) {
            if ($address->getLat() !== null && $address->getLng() !== null) {
                $this->logger->debug(__(
                    "Shipment %1 address has existing coords: %2, %3",
                    $shipmentId,
                    $address->getLat(),
                    $address->getLng()
                ));
                $addressCoords = $this->coordinateFactory->create([
                    'latitude' => $address->getLat(),
                    'longitude' => $address->getLng(),
                ]);
            } else {
                $this->logger->debug(__("Calculating address coords for shipment %1", $shipmentId));
                $addressCoords = $this->geoCode->getGeoCoordinateByAddress($address);
                $this->logger->debug(__(
                    "Calculated address coords for shipment %1, address %2: %3, %4",
                    $shipmentId,
                    $address->getEntityId(),
                    $addressCoords->getLatitude(),
                    $addressCoords->getLongitude()
                ));

                $address->setLat($addressCoords->getLatitude());
                $address->setLng($addressCoords->getLongitude());
                $this->addressRepository->save($address);
            }
            $finalAirport = $this->findClosestAirport($addressCoords, $address->getCountryId());
            $debugMessage = "Shipment %1 has nearest airport to destination: %2";
            $this->logger->debug(__($debugMessage, $shipmentId, $finalAirport->getCode()));
        } else {
            $this->logger->debug(__(
                "Shipment %1 only using road freight, as airport %2 doesn't service domestic",
                $shipmentId,
                $startingAirport->getCode()
            ));
            $onlyRoadFreight = true;
        }

        $totalDistance = 0;
        if (!$onlyRoadFreight && $finalAirport && $finalAirport->getCode() != $startingAirport->getCode()) {
            $this->logger->debug(__(
                "Calculating flight-inclusive distance for shipment %1 from airport %2 to %3",
                $shipmentId,
                $startingAirport->getCode(),
                $finalAirport->getCode()
            ));
            $flightLegDistance = $this->haversine->calculateDistance(
                $startingAirport->getCoordinates(),
                $finalAirport->getCoordinates()
            );
            $this->logger->debug(__(
                "Flight leg distance for shipment %1 (%2-%3): %4",
                $shipmentId,
                $startingAirport->getCode(),
                $finalAirport->getCode(),
                $flightLegDistance
            ));

            $finalLegDistance = $this->distanceCalculator->calculateDistance($finalAirport->getCoordinates(), $address);
            $this->logger->debug(__("Final leg distance for shipment %1: %2", $shipmentId, $finalLegDistance));

            $carbonEmissionsPerKg = ($warehouseAirportDistance + $finalLegDistance) * $roadEmissionRate;
            $carbonEmissionsPerKg += $flightLegDistance * $airEmissionRate;
            $totalDistance = $warehouseAirportDistance + $finalLegDistance + $flightLegDistance;
        } else {
            $this->logger->debug(__("Calculating road-only distance for shipment %1", $shipmentId));
            try {
                $roadDistance = $this->distanceCalculator->calculateDistance($warehouse, $address);
            } catch (\Exception $ex) {
                $errorMessage = '%1 calculating road-only distance for shipment %2';
                $this->logger->error(__($errorMessage, get_class($ex), $shipmentId));
                throw $ex;
            }
            $this->logger->debug(__("Road-only distance for shipment %1: %2", $shipmentId, $roadDistance));
            $carbonEmissionsPerKg = $roadDistance * $roadEmissionRate;
            $totalDistance = $roadDistance;
        }
        $carbonEmissions = $carbonEmissionsPerKg * $shipmentWeight;

        $this->logger->debug(__("Carbon emissions for shipment %1: %2", $shipmentId, $carbonEmissions));

        $data = [
            'distance' => $totalDistance,
            'carbon_emissions' => $carbonEmissions,
        ];

        /** @var \EcoBahn\CarbonCalculator\Api\Data\CarbonCalculatorResultInterface $result */
        $result = $this->calculatorResultFactory->create(['data' => $data]);

        return $result;
    }
}
