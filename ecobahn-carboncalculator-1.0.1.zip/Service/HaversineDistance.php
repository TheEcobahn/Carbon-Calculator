<?php
/**
 * @copyright Copyright (c) Aligent Consulting. (http://www.aligent.com.au)
 * @license https://opensource.org/licenses/osl-3.0.php OSL-3.0
 */

namespace EcoBahn\CarbonCalculator\Service;

use EcoBahn\CarbonCalculator\Api\Data\GeoCoordinateInterface;

class HaversineDistance
{
    const EQUATOR_RADIUS = 6335.439;

    public function haversine($radiansAngle)
    {
        return pow(sin($radiansAngle / 2), 2);
    }

    /**
     * Calculate approximate distance (in km) between two geo-coordinates using the haversine formula
     * @see https://en.wikipedia.org/wiki/Haversine_formula
     * @param GeoCoordinateInterface $start
     * @param GeoCoordinateInterface $end
     * @return float
     */
    public function calculateDistance(GeoCoordinateInterface $start, GeoCoordinateInterface $end): float
    {
        $startLat = deg2rad($start->getLatitude());
        $startLong = deg2rad($start->getLongitude());
        $endLat = deg2rad($end->getLatitude());
        $endLong = deg2rad($end->getLongitude());

        $dist = 2 * self::EQUATOR_RADIUS * asin(sqrt(
            $this->haversine($endLat - $startLat) +
            (cos($startLat) * cos($endLat) * $this->haversine($endLong - $startLong))
        ));
        return $dist;
    }
}
