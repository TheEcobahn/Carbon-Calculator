<?php
/**
 * @copyright Copyright (c) Aligent Consulting. (http://www.aligent.com.au)
 * @license https://opensource.org/licenses/osl-3.0.php OSL-3.0
 */

namespace EcoBahn\CarbonCalculator\Service;

use Magento\Framework\Api\ExtensibleDataInterface;
use EcoBahn\CarbonCalculator\Model\GeoCoordinate;

class Geocode implements \EcoBahn\CarbonCalculator\Api\GeoCodeInterface
{
    /**
     * @var $googleRestApi
     */
    private $googleRestApi;
    /**
     * @var \EcoBahn\CarbonCalculator\Helper\ConfigHelper
     */
    private $configHelper;
    /**
     * @var \Psr\Log\LoggerInterface
     */
    private $logger;
    /**
     * @var \EcoBahn\CarbonCalculator\Api\Data\GeoCoordinateInterfaceFactory
     */
    private $geoCoordinateInterfaceFactory;
    /**
     * @var \Magento\Framework\Serialize\Serializer\Json
     */
    private $jsonSerialzer;

    /**
     * Geocode constructor.
     * @param \EcoBahn\CarbonCalculator\Model\GoogleRestApi $googleRestApi
     * @param \EcoBahn\CarbonCalculator\Helper\ConfigHelper $configHelper
     * @param \EcoBahn\CarbonCalculator\Api\Data\GeoCoordinateInterfaceFactory $geoCoordinateInterfaceFactory
     * @param \Magento\Framework\Serialize\Serializer\Json $jsonSerializer
     * @param \Psr\Log\LoggerInterface $logger
     */
    public function __construct(
        \EcoBahn\CarbonCalculator\Model\GoogleRestApi $googleRestApi,
        \EcoBahn\CarbonCalculator\Helper\ConfigHelper $configHelper,
        \EcoBahn\CarbonCalculator\Api\Data\GeoCoordinateInterfaceFactory $geoCoordinateInterfaceFactory,
        \Magento\Framework\Serialize\Serializer\Json $jsonSerializer,
        \Psr\Log\LoggerInterface $logger
    ) {
        $this->googleRestApi = $googleRestApi;
        $this->configHelper = $configHelper;
        $this->geoCoordinateInterfaceFactory = $geoCoordinateInterfaceFactory;
        $this->jsonSerialzer = $jsonSerializer;
        $this->logger = $logger;
    }

    /**
     * @see https://developers.google.com/maps/documentation/geocoding/intro#GeocodingRequests
     * @param ExtensibleDataInterface $address (\Magento\Sales\Api\Data\OrderAddressInterface or similar)
     * @return GeoCoordinate|null
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getGeoCoordinateByAddress(ExtensibleDataInterface $address): ?GeoCoordinate
    {
        try {
            $response = $this->googleRestApi->callGoogleApi(
                $this->configHelper->getGeoCodeApiUrl(),
                \Magento\Framework\HTTP\ZendClient::GET,
                [
                    'key' => $this->configHelper->getGeocodeApiKey(),
                    'address' => $this->formatAddress($address)
                ]
            );
        } catch (\Exception $e) {
            $this->logger->error("Geocode request failed " . $e->getMessage());
            throw new \Magento\Framework\Exception\LocalizedException(
                __("Failed to send request to the remote server"),
                null,
                400
            );
        }

        return $this->getLocation($response['results'][0]);
    }

    /**
     * @see https://developers.google.com/maps/documentation/geocoding/intro#Results
     * @param $result
     * @return GeoCoordinate|null
     */
    private function getLocation($result)
    {
        if (isset($result['geometry'])) {
            return $this->geoCoordinateInterfaceFactory->create(
                [
                    'latitude' => $result['geometry']['location']['lat'],
                    'longitude' => $result['geometry']['location']['lng']
                ]
            );
        }
        return null;
    }

    /**
     * @see https://developers.google.com/maps/documentation/geocoding/intro#geocoding
     * @param ExtensibleDataInterface $address (\Magento\Sales\Api\Data\OrderAddressInterface or similar)
     * @return string $googleAddress
     */
    private function formatAddress(ExtensibleDataInterface $address): string
    {
        $arrayAddress = array_merge(
            $address->getStreet(),
            [
                $address->getCity(),
                $address->getRegionCode(),
                $address->getCountryId(),
                $address->getPostcode()
            ]
        );
        return implode(',', $arrayAddress);
    }
}
