<?php
/**
 * @copyright Copyright (c) Aligent Consulting. (http://www.aligent.com.au)
 * @license https://opensource.org/licenses/osl-3.0.php OSL-3.0
 */

namespace EcoBahn\CarbonCalculator\Setup\Patch\Data;

use Magento\Framework\Setup\Patch\DataPatchInterface;

class AirportList implements DataPatchInterface
{
    const COL_CODE = 0;
    const COL_NAME = 1;
    const COL_COUNTRY = 2;
    const COL_LAT = 3;
    const COL_LNG = 4;
    const COL_DOMESTIC = 5;
    const COL_ACCESS_COUNTRIES = 6;

    /** @var \Magento\Framework\Filesystem\File\ReadFactory */
    private $readFactory;

    /** @var \Magento\Framework\Filesystem\Driver\FileFactory */
    private $fileDriverFactory;

    /** @var \EcoBahn\CarbonCalculator\Model\ResourceModel\Airport */
    private $airportResource;

    /** @var \EcoBahn\CarbonCalculator\Model\AirportFactory */
    private $airportFactory;

    public function __construct(
        \Magento\Framework\Filesystem\File\ReadFactory $readFactory,
        \Magento\Framework\Filesystem\Driver\FileFactory $fileDriverFactory,
        \EcoBahn\CarbonCalculator\Model\ResourceModel\Airport $airportResource,
        \EcoBahn\CarbonCalculator\Model\AirportFactory $airportFactory
    ) {
        $this->readFactory = $readFactory;
        $this->fileDriverFactory = $fileDriverFactory;
        $this->airportResource = $airportResource;
        $this->airportFactory = $airportFactory;
    }

    /**
     * @inheritDoc
     */
    public function getAliases()
    {
        return [];
    }

    public static function getDependencies()
    {
        return [];
    }

    /**
     * @inheritDoc
     */
    public function apply()
    {
        $csvPath = __DIR__ . '/raw/airport_list.csv';
        $fileDriver = $this->fileDriverFactory->create();

        /** @var \Magento\Framework\Filesystem\File\Read $reader */
        $reader = $this->readFactory->create($csvPath, $fileDriver);

        $header = $reader->readCsv();
        while ($line = $reader->readCsv()) {
            $countryList = array_filter(preg_split('/,\s*/', $line[self::COL_ACCESS_COUNTRIES]));
            if (count($countryList) > 0) {
                $accessibleCountries = ',' . implode(',', $countryList) . ',';
            } else {
                $accessibleCountries = '';
            }

            /** @var \EcoBahn\CarbonCalculator\Model\Airport $airport */
            $airport = $this->airportFactory->create();

            // Prevent transaction rollback if airport data manually added before patch
            $this->airportResource->load($airport, $line[self::COL_CODE]);
            if ($airport->getCountry()) {
                $airport->isObjectNew(false);
            }

            $airport->setCode($line[self::COL_CODE]);
            $airport->setName($line[self::COL_NAME]);
            $airport->setCountry($line[self::COL_COUNTRY]);
            $airport->setLat($line[self::COL_LAT]);
            $airport->setLng($line[self::COL_LNG]);
            $airport->setServicesDomestic($line[self::COL_DOMESTIC]);
            $airport->setAccessibleCountries($accessibleCountries);

            $this->airportResource->save($airport);
        }

        return $this;
    }
}
