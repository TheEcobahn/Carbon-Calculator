<?php
/**
 * @copyright Copyright (c) Aligent Consulting. (http://www.aligent.com.au)
 * @license https://opensource.org/licenses/osl-3.0.php OSL-3.0
 */

namespace EcoBahn\CarbonCalculator\Setup\Patch\Schema;

use Magento\Framework\Setup\Patch\SchemaPatchInterface;
use EcoBahn\CarbonCalculator\Model\ResourceModel\Airport as AirportResourceModel;

class AirportEntity implements SchemaPatchInterface
{
    const COLUMN_CODE = 'code';
    const COLUMN_NAME = 'name';
    const COLUMN_COUNTRY = 'country';
    const COLUMN_LATITUDE = 'lat';
    const COLUMN_LONGITUDE = 'lng';
    const COLUMN_SERVICES_DOMESTIC = 'services_domestic';
    const COLUMN_ACCESSIBLE_COUNTRIES = 'accessible_countries';

    /** @var \Magento\Framework\Setup\ModuleDataSetupInterface */
    private $dataSetup;

    /** @var \Magento\Eav\Setup\EavSetupFactory */
    private $eavSetupFactory;

    /**
     * @inheritDoc
     */
    public static function getDependencies()
    {
        return [];
    }

    public function __construct(
        \Magento\Framework\Setup\ModuleDataSetupInterface $dataSetup,
        \Magento\Eav\Setup\EavSetupFactory $eavSetupFactory
    ) {
        $this->dataSetup = $dataSetup;
        $this->eavSetupFactory = $eavSetupFactory;
    }

    /**
     * @inheritDoc
     */
    public function getAliases()
    {
        return [];
    }

    /**
     * @inheritDoc
     */
    public function apply()
    {
        /** @var \Magento\Eav\Setup\EavSetup $eavSetup */
        $eavSetup = $this->eavSetupFactory->create(['setup' => $this->dataSetup]);

        $tblParams = [
            'entity_model' => AirportResourceModel::class,
            'table' => AirportResourceModel::ENTITY_TABLE,
            'id_field' => AirportResourceModel::ID_FIELD,
        ];
        $eavSetup->addEntityType(AirportResourceModel::ENTITY_TABLE, $tblParams);
    }
}
