<?php
/**
 * @copyright Copyright (c) Aligent Consulting. (http://www.aligent.com.au)
 * @license https://opensource.org/licenses/osl-3.0.php OSL-3.0
 */

namespace EcoBahn\CarbonCalculator\Controller\Adminhtml\Report;

use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Reports\Controller\Adminhtml\Report\AbstractReport;
use EcoBahn\CarbonCalculator\Block\Adminhtml\Report\Emissions\Grid;

class ExportEmissionsCsv extends AbstractReport
{
    /**
     * Export emissions report grid to CSV format
     *
     * @return \Magento\Framework\App\ResponseInterface
     */
    public function execute()
    {
        $fileName = 'emissions.csv';
        /** @var \EcoBahn\CarbonCalculator\Block\Adminhtml\Report\Emissions\Grid $grid */
        $grid = $this->_view->getLayout()->createBlock(Grid::class);
        $this->_initReportAction($grid);
        return $this->_fileFactory->create($fileName, $grid->getCsvFile(), DirectoryList::VAR_DIR);
    }
}
