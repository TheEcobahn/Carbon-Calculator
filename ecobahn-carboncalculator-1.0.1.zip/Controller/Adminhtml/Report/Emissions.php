<?php
/**
 * @copyright Copyright (c) Aligent Consulting. (http://www.aligent.com.au)
 *            Includes code Copyright (c) Magento, Inc.
 * @license https://opensource.org/licenses/osl-3.0.php OSL-3.0
 */

namespace EcoBahn\CarbonCalculator\Controller\Adminhtml\Report;

use Magento\Reports\Controller\Adminhtml\Report\AbstractReport;
use Magento\Framework\App\Action\HttpGetActionInterface as HttpGetActionInterface;
use EcoBahn\CarbonCalculator\Model\Flag;

/**
 * Based on \Magento\Reports\Controller\Adminhtml\Report\Sales\Bestsellers
 */
class Emissions extends AbstractReport implements HttpGetActionInterface
{
    /**
     * @return void
     */
    public function execute()
    {
        $this->_showLastExecutionTime(Flag::REPORT_EMISSIONS_FLAG_CODE, 'ecobahn_carbon_emissions');

        $this->_initAction()->_setActiveMenu(
            'EcoBahn_CarbonCalculator::report_emissions'
        )->_addBreadcrumb(
            __('Carbon Emissions Report'),
            __('Carbon Emissions Report')
        );
        $this->_view->getPage()->getConfig()->getTitle()->prepend(__('Carbon Emissions Report'));

        $gridBlock = $this->_view->getLayout()->getBlock('adminhtml_report_emissions.grid');
        $filterFormBlock = $this->_view->getLayout()->getBlock('grid.filter.form');

        $this->_initReportAction([$gridBlock, $filterFormBlock]);

        $this->_view->renderLayout();
    }
}
