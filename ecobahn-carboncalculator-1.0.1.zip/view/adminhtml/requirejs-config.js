var config = {
    map: {
        '*': {
            chartJs: 'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.js'
        }
    }
}
