<?php
/**
 * @copyright Copyright (c) Aligent Consulting. (http://www.aligent.com.au)
 * @license https://opensource.org/licenses/osl-3.0.php OSL-3.0
 */

namespace EcoBahn\CarbonCalculator\Plugin;

use EcoBahn\CarbonCalculator\Api\CarbonCalculatorInterface;
use EcoBahn\CarbonCalculator\Helper\ConfigHelper;
use Magento\Framework\Model\AbstractModel;
use Magento\Sales\Model\Spi\ShipmentResourceInterface;

class ShipmentSavePlugin
{
    /**
     * @var CarbonCalculatorInterface
     */
    private $carbonCalculator;
    /**
     * @var ConfigHelper
     */
    private $configHelper;
    /**
     * @var array Shipment ID => true, to prevent recursion
     */
    private $emissionsCalculated = [];

    /**
     * ShipmentSavePlugin constructor.
     *
     * @param CarbonCalculatorInterface $carbonCalculator
     * @param ConfigHelper              $configHelper
     */
    public function __construct(
        CarbonCalculatorInterface $carbonCalculator,
        ConfigHelper $configHelper
    ) {
        $this->carbonCalculator = $carbonCalculator;
        $this->configHelper = $configHelper;
    }

    /**
     * @param ShipmentResourceInterface $subject
     * @param ShipmentResourceInterface $result
     * @param AbstractModel             $object
     * @return ShipmentResourceInterface
     */
    public function afterSave(
        ShipmentResourceInterface $subject,
        $result,
        AbstractModel $object
    ) {
        $shipmentId = (int)$object->getEntityId();
        $alreadyProcessed = !empty($this->emissionsCalculated[$shipmentId]);
        if (!$object->getData($this->configHelper::SALES_SHIPMENT_CARBON_EMISSIONS_FIELD) && !$alreadyProcessed) {
            $this->emissionsCalculated[$shipmentId] = true;
            try {
                /** @var \EcoBahn\CarbonCalculator\Api\Data\CarbonCalculatorResultInterface $calculation */
                $calculation = $this->carbonCalculator->calculateShipmentEmissions($object);
            } catch (\Exception $ex) {
                // can't do anything useful if calculation fails
                return $result;
            }
            $object->setData(
                $this->configHelper::SALES_SHIPMENT_DISTANCE_FIELD,
                $calculation->getDistance()
            );
            $object->setData(
                $this->configHelper::SALES_SHIPMENT_CARBON_EMISSIONS_FIELD,
                $calculation->getCarbonEmissions()
            );
            $subject->save($object);
        }
        return $result;
    }
}
