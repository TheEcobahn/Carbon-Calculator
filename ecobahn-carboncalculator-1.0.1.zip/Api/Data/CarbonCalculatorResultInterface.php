<?php
/**
 * @copyright Copyright (c) Aligent Consulting. (http://www.aligent.com.au)
 * @license https://opensource.org/licenses/osl-3.0.php OSL-3.0
 */

namespace EcoBahn\CarbonCalculator\Api\Data;

interface CarbonCalculatorResultInterface
{
    public function getDistance(): ?float;

    public function getCarbonEmissions(): ?float;
}
