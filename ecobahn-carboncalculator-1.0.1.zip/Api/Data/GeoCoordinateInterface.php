<?php
/**
 * @copyright Copyright (c) Aligent Consulting. (http://www.aligent.com.au)
 * @license https://opensource.org/licenses/osl-3.0.php OSL-3.0
 */

namespace EcoBahn\CarbonCalculator\Api\Data;

use Magento\Framework\Api\ExtensibleDataInterface;

interface GeoCoordinateInterface extends ExtensibleDataInterface
{
    /**
     * @return float
     */
    public function getLatitude(): float;

    /**
     * @return float
     */
    public function getLongitude(): float;
}
