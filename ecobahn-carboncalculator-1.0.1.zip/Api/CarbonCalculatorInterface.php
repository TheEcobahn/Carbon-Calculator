<?php
/**
 * @copyright Copyright (c) Aligent Consulting. (http://www.aligent.com.au)
 * @license https://opensource.org/licenses/osl-3.0.php OSL-3.0
 */

namespace EcoBahn\CarbonCalculator\Api;

use Magento\Sales\Api\Data\ShipmentInterface;
use EcoBahn\CarbonCalculator\Api\Data\CarbonCalculatorResultInterface;

interface CarbonCalculatorInterface
{
    public function calculateShipmentEmissions(ShipmentInterface $shipment): CarbonCalculatorResultInterface;
}
