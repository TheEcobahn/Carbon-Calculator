<?php
/**
 * @copyright Copyright (c) Aligent Consulting. (http://www.aligent.com.au)
 * @license https://opensource.org/licenses/osl-3.0.php OSL-3.0
 */

namespace EcoBahn\CarbonCalculator\Api;

use EcoBahn\CarbonCalculator\Model\GeoCoordinate;
use Magento\Framework\Api\ExtensibleDataInterface;

interface GeoCodeInterface
{
    /**
     * For a given address return geo coordinate.
     * @see https://developers.google.com/maps/documentation/geocoding/intro#GeocodingRequests
     * @param ExtensibleDataInterface $address (\Magento\Sales\Api\Data\OrderAddressInterface or similar)
     * @return GeoCoordinate|null
     */
    public function getGeoCoordinateByAddress(ExtensibleDataInterface $address): ?GeoCoordinate;
}
