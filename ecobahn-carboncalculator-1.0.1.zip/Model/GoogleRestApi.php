<?php
/**
 * @copyright Copyright (c) Aligent Consulting. (http://www.aligent.com.au)
 * @license https://opensource.org/licenses/osl-3.0.php OSL-3.0
 */

namespace EcoBahn\CarbonCalculator\Model;

use EcoBahn\CarbonCalculator\Helper\ConfigHelper;
use Magento\Framework\Exception\InvalidRequestException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\HTTP\ZendClientFactory;
use Magento\Framework\Serialize\Serializer\Json;
use Psr\Log\LoggerInterface;

class GoogleRestApi
{
    /**
     * @var ConfigHelper
     */
    private $configHelper;

    /**
     * @var LoggerInterface
     */
    private $logger;
    /**
     * @var ZendClientFactory
     */
    private $httpClientFactory;
    /**
     * @var Json
     */
    private $jsonSerializer;

    /**
     * @param ZendClientFactory $httpClientFactory
     * @param ConfigHelper $configHelper
     * @param Json $jsonSerializer
     * @param LoggerInterface $logger
     */
    public function __construct(
        ZendClientFactory $httpClientFactory,
        ConfigHelper $configHelper,
        Json $jsonSerializer,
        LoggerInterface $logger
    ) {
        $this->httpClientFactory = $httpClientFactory;
        $this->configHelper = $configHelper;
        $this->jsonSerializer = $jsonSerializer;
        $this->logger = $logger;
    }

    /**
     * @param $url
     * @param $requestMethod
     * @param array $data
     * @param array $headers
     * @return array|string
     * @throws LocalizedException
     * @throws \Zend_Http_Client_Exception
     */
    public function callGoogleApi($url, $requestMethod, $data, $headers = [])
    {
        /** @var \Magento\Framework\HTTP\ZendClient $client */
        $client = $this->httpClientFactory->create([
            'config' => [
                'timeout' => 4
            ]
        ]);

        $client->setUri($url);
        $client->setMethod($requestMethod);

        if (!empty($headers)) {
            $client->setHeaders($headers);
        }

        if ($requestMethod == \Zend_Http_Client::PUT ||
            $requestMethod == \Zend_Http_Client::POST) {
            $client->setRawData($this->json->serialize($data), 'application/json');
            $client->setHeaders('Content-Type', 'application/json');
        } else {
            $client->setParameterGet($data);
        }

        try {
            $response = $client->request();
        } catch (\Exception $e) {
            $this->logger->warning('Unable to contact Google API');
            throw new LocalizedException(
                __("An unexpected error occurred, please try again or contact customer service.")
            );
        }

        if ($response->getStatus() !== $this->configHelper::GEOCODE_RESPONSE_STATUS) {
            $this->logger->warning("Remote Error", $response->getStatus());
            throw new InvalidRequestException("Remote Error", $response->getStatus());
        }

        $responseBody = $response->getBody();

        return $this->jsonSerializer->unserialize($responseBody);
    }
}
