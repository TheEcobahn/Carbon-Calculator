<?php
/**
 * @copyright Copyright (c) Aligent Consulting. (http://www.aligent.com.au)
 *            Includes code Copyright (c) Magento, Inc.
 * @license https://opensource.org/licenses/osl-3.0.php OSL-3.0
 */

namespace EcoBahn\CarbonCalculator\Model\ResourceModel\Report;

use EcoBahn\CarbonCalculator\Model\Flag;
use Exception;
use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\Model\ResourceModel\Db\Context;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Magento\Framework\Stdlib\DateTime\Timezone\Validator;
use Magento\Reports\Model\FlagFactory;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Reports\Model\ResourceModel\Report\AbstractReport;
use Psr\Log\LoggerInterface;
use Zend_Db_Expr;

/**
 * Based on \Magento\Sales\Model\ResourceModel\Report\Bestsellers::aggregate
 */
class CarbonEmission extends AbstractReport
{
    const AGGREGATION_DAILY = 'daily';

    const SALES_SHIPMENT = 'sales_shipment';
    /**
     * @var LoggerInterface
     */
    private $logger;
    /**
     * @var false|AdapterInterface
     */
    private $connection;

    /**
     * @param Context $context
     * @param LoggerInterface $logger
     * @param TimezoneInterface $localeDate
     * @param FlagFactory $reportsFlagFactory
     * @param Validator $timezoneValidator
     * @param DateTime $dateTime
     * @param string $connectionName
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function __construct(
        Context $context,
        LoggerInterface $logger,
        TimezoneInterface $localeDate,
        FlagFactory $reportsFlagFactory,
        Validator $timezoneValidator,
        DateTime $dateTime,
        $connectionName = null
    ) {
        parent::__construct(
            $context,
            $logger,
            $localeDate,
            $reportsFlagFactory,
            $timezoneValidator,
            $dateTime,
            $connectionName
        );
        $this->logger = $logger;
        $this->dateTime = $dateTime;
    }

    /**
     * Model initialization
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('carbon_creds_aggregated_' . self::AGGREGATION_DAILY, 'id');
    }

    /**
     * Aggregate emissions data by shipping - created at
     *
     * @param null $from
     * @param null $to
     * @return $this
     * @throws Exception
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function aggregate($from = null, $to = null)
    {
        try {

            $this->connection = $this->getConnection();

            $this->connection->beginTransaction();

            //date range for the last 25 hours
            if ($from !== null || $to !== null) {
                $subSelect = $this->_getTableDateRangeSelect(
                    $this->getTable(self::SALES_SHIPMENT),
                    'created_at',
                    'updated_at',
                    $from,
                    $to
                );
            } else {
                $subSelect = null;
            }

            $this->_clearTableByDateRange($this->getMainTable(), $from, $to, $subSelect);

            $periodExpr = $this->connection->getDatePartSql(
                $this->getStoreTZOffsetQuery(
                    ['source_table' => $this->getTable(self::SALES_SHIPMENT)],
                    'source_table.created_at',
                    $from,
                    $to
                )
            );

            $select = $this->connection->select();
            $select->reset();
            $columns = [
                'period' => $periodExpr,
                'store_id' => 'source_table.store_id',
                'shipping_country' => 'sales_order_address.country_id',
                'carbon_emissions_total' => new Zend_Db_Expr(
                    'SUM(source_table.carbon_emissions)'
                ),
                'carbon_distance_total' => new Zend_Db_Expr(
                    'SUM(source_table.carbon_distance)'
                ),
                'carbon_emissions_offset' => new Zend_Db_Expr(
                    'SUM(source_table.carbon_emissions * source_table.carbon_creds_purchased)'
                ),
                'carbon_price_total' => new Zend_Db_Expr(
                    'SUM(source_table.carbon_creds_price)'
                ),
                'carbon_price_paid' => new Zend_Db_Expr(
                    'SUM(source_table.carbon_creds_price * source_table.carbon_creds_purchased)'
                ),
            ];

            $select->group([$periodExpr, 'source_table.store_id', 'sales_order_address.country_id']);

            $select->from(
                ['source_table' => $this->getTable(self::SALES_SHIPMENT)],
                $columns
            )->where(
                'source_table.carbon_emissions IS NOT NULL'
            );

            $select->joinLeft(
                'sales_order_address',
                'source_table.shipping_address_id = sales_order_address.entity_id',
                []
            );

            if ($subSelect !== null) {
                $select->having($this->_makeConditionFromDateRangeSelect($subSelect, 'period'));
            }

            // daily aggregation
            $insertQuery = $select->insertFromSelect($this->getMainTable(), array_keys($columns));
            $this->connection->query($insertQuery);

            $this->_setFlagData(Flag::REPORT_EMISSIONS_FLAG_CODE);

            $this->connection->commit();

        } catch (Exception $e) {
            $this->logger->info('Carbon Emission Aggregation Error ' . $e->getTraceAsString());
            $this->connection->rollBack();
            throw $e;
        }

        return $this;
    }
}
