<?php
/**
 * @copyright Copyright (c) Aligent Consulting. (http://www.aligent.com.au)
 * @license https://opensource.org/licenses/osl-3.0.php OSL-3.0
 */

namespace EcoBahn\CarbonCalculator\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class Airport extends AbstractDb
{
    const ENTITY_TABLE = 'ecobahn_airport';
    const ID_FIELD = 'code';

    protected $_useIsObjectNew = true;

    protected $_isPkAutoIncrement = false;

    protected function _construct()
    {
        $this->_init(self::ENTITY_TABLE, self::ID_FIELD);
    }
}
