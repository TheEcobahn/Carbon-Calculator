<?php
/**
 * @copyright Copyright (c) Aligent Consulting. (http://www.aligent.com.au)
 * @license https://opensource.org/licenses/osl-3.0.php OSL-3.0
 */

namespace EcoBahn\CarbonCalculator\Model\ResourceModel\Airport;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    protected function _construct()
    {
        $this->_init(
            \EcoBahn\CarbonCalculator\Model\Airport::class,
            \EcoBahn\CarbonCalculator\Model\ResourceModel\Airport::class
        );
    }
}
