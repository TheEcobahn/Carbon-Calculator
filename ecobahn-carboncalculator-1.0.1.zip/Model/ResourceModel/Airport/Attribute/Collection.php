<?php
/**
 * @copyright Copyright (c) Aligent Consulting. (http://www.aligent.com.au)
 * @license https://opensource.org/licenses/osl-3.0.php OSL-3.0
 */

namespace EcoBahn\CarbonCalculator\Model\ResourceModel\Airport\Attribute;

use Magento\Framework\Data\Collection\EntityFactoryInterface;
use Magento\Eav\Model\AttributeFactory;
use Magento\Eav\Model\Entity\Attribute;
use Magento\Eav\Model\Entity\TypeFactory;
use EcoBahn\CarbonCalculator\Model\ResourceModel\Airport as AirportResourceModel;

class Collection extends \Magento\Framework\Data\Collection implements \IteratorAggregate
{
    // No EAV attributes on this table; generate attributes on the fly
    const AIRPORT_CODE = 1;
    const AIRPORT_NAME = 2;
    const AIRPORT_COUNTRY = 3;
    const AIRPORT_LATITUDE = 4;
    const AIRPORT_LONGITUDE = 5;
    const AIRPORT_SERVICES_DOMESTIC = 6;
    const AIRPORT_ACCESSIBLE_COUNTRIES = 7;

    const COLUMN_CODE = 'code';
    const COLUMN_NAME = 'name';
    const COLUMN_COUNTRY = 'country';
    const COLUMN_LATITUDE = 'lat';
    const COLUMN_LONGITUDE = 'lng';
    const COLUMN_SERVICES_DOMESTIC = 'services_domestic';
    const COLUMN_ACCESSIBLE_COUNTRIES = 'accessible_countries';

    public function __construct(
        EntityFactoryInterface $entityFactory,
        AttributeFactory $attributeFactory,
        TypeFactory $typeFactory
    ) {
        parent::__construct($entityFactory);

        $type = $typeFactory->create();
        $type->loadByCode(AirportResourceModel::ENTITY_TABLE);
        $typeId = $type->getId();

        foreach ($this->getItemDefinitions() as $itemDef) {
            $itemDef['entity_type_id'] = $typeId;
            $attr = $attributeFactory->createAttribute(Attribute::class, $itemDef);
            $attr->setEntityType($type);
            $this->_addItem($attr);
        }
    }

    private function getItemDefinitions()
    {
        return [
            [
                'attribute_id' => self::AIRPORT_CODE,
                'attribute_code' => self::COLUMN_CODE,
                'frontend_label' => __('IATA or ICAO code'),
                'backend_type' => 'static',
                'is_required' => true,
            ],
            [
                'attribute_id' => self::AIRPORT_NAME,
                'attribute_code' => self::COLUMN_NAME,
                'frontend_label' => __('Name of airport or city'),
                'backend_type' => 'static',
                'is_required' => true,
            ],
            [
                'attribute_id' => self::AIRPORT_COUNTRY,
                'attribute_code' => self::COLUMN_COUNTRY,
                'frontend_label' => __('Code of country in which the airport exists'),
                'backend_type' => 'static',
                'is_required' => true,
            ],
            [
                'attribute_id' => self::AIRPORT_LATITUDE,
                'attribute_code' => self::COLUMN_LATITUDE,
                'frontend_label' => __('Latitude'),
                'backend_type' => 'static',
                'is_required' => true,
            ],
            [
                'attribute_id' => self::AIRPORT_LONGITUDE,
                'attribute_code' => self::COLUMN_LONGITUDE,
                'frontend_label' => __('Longitude'),
                'backend_type' => 'static',
                'is_required' => true,
            ],
            [
                'attribute_id' => self::AIRPORT_SERVICES_DOMESTIC,
                'attribute_code' => self::COLUMN_SERVICES_DOMESTIC,
                'frontend_label' => __('Has domestic flights?'),
                'backend_type' => 'static',
                'is_required' => true,
            ],
            [
                'attribute_id' => self::AIRPORT_ACCESSIBLE_COUNTRIES,
                'attribute_code' => self::COLUMN_ACCESSIBLE_COUNTRIES,
                'frontend_label' => __('Is accessible by road only from the listed countries'),
                'backend_type' => 'static',
                'is_required' => true,
            ],
        ];
    }
}
