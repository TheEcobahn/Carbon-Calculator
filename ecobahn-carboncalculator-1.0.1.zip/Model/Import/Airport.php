<?php
/**
 * @copyright Copyright (c) Aligent Consulting. (http://www.aligent.com.au)
 * @license https://opensource.org/licenses/osl-3.0.php OSL-3.0
 */

namespace EcoBahn\CarbonCalculator\Model\Import;

use Magento\ImportExport\Model\Import;
use Magento\ImportExport\Model\Import\Entity\AbstractEntity;
use EcoBahn\CarbonCalculator\Model\ResourceModel\Airport as AirportResourceModel;
use EcoBahn\CarbonCalculator\Model\ResourceModel\Airport\Attribute\Collection;

class Airport extends AbstractEntity
{
    const ENTITY_TYPE_CODE = 'ecobahn_airport';

    const VALIDATION_EMPTY_FIELD = 'RequiredFieldMissing';
    const VALIDATION_INVALID_COORD = 'InvalidCoordinate';

    public function getEntityTypeCode()
    {
        return self::ENTITY_TYPE_CODE;
    }

    public function validateRow(array $rowData, $rowNum)
    {
        if (isset($this->_validatedRows[$rowNum])) {
            return !$this->getErrorAggregator()->isRowInvalid($rowNum);
        }
        $this->_validatedRows[$rowNum] = true;

        $nonEmptyCols = [
            Collection::COLUMN_CODE,
            Collection::COLUMN_NAME,
            Collection::COLUMN_COUNTRY,
        ];
        foreach ($nonEmptyCols as $col) {
            if (empty($rowData[$col])) {
                $this->addRowError(self::VALIDATION_EMPTY_FIELD, $rowNum);
                return false;
            }
        }

        $numericalCols = [Collection::COLUMN_LONGITUDE, Collection::COLUMN_LATITUDE];
        foreach ($numericalCols as $col) {
            if (!isset($rowData[$col])) {
                $this->addRowError(self::VALIDATION_EMPTY_FIELD, $rowNum);
                return false;
            }
            $datum = $rowData[$col];

            // N.B. Magento exports negative coords with a space before the minus sign
            if (!preg_match('/^(?:\s*\-)?\d+(?:\.\d+)?$/', $datum) || $datum > 180 || $datum < -180) {
                $this->addRowError(self::VALIDATION_INVALID_COORD, $rowNum);
                return false;
            }
        }

        return !$this->getErrorAggregator()->isRowInvalid($rowNum);
    }

    protected function _importData()
    {
        $behavior = $this->getBehavior();

        if ($behavior !== Import::BEHAVIOR_REPLACE) {
            throw new \RuntimeException(__('Invalid import behavior'));
        }

        $tableName = $this->_connection->getTableName(AirportResourceModel::ENTITY_TABLE);
        $allCodes = [];
        $terminated = false;
        while ($bunch = $this->_dataSourceModel->getNextBunch()) {
            $entityList = [];
            foreach ($bunch as $rowNum => $rowData) {
                if (!$this->validateRow($rowData, $rowNum)) {
                    continue;
                }
                if ($this->getErrorAggregator()->hasToBeTerminated()) {
                    $this->getErrorAggregator()->addRowToSkip($rowNum);
                    $terminated = true;
                    continue;
                }

                // In DB the accessible_countries is an empty string if there are no countries, otherwise it is a
                // comma-separated list with commas at the start and end so matching is simple, e.g. contains ',AU,'
                $countries = '';
                $countriesArr = preg_split('/,\s*/', $rowData[Collection::COLUMN_ACCESSIBLE_COUNTRIES]);
                $countriesArr = array_filter($countriesArr);
                if (count($countriesArr) > 0) {
                    $countries = ',' . implode(',', $countriesArr) . ',';
                }

                $allCodes[] = $rowData[Collection::COLUMN_CODE];
                $entityList[] = [
                    Collection::COLUMN_CODE => $rowData[Collection::COLUMN_CODE],
                    Collection::COLUMN_NAME => $rowData[Collection::COLUMN_NAME],
                    Collection::COLUMN_COUNTRY => $rowData[Collection::COLUMN_COUNTRY],
                    Collection::COLUMN_LATITUDE => $rowData[Collection::COLUMN_LATITUDE],
                    Collection::COLUMN_LONGITUDE => $rowData[Collection::COLUMN_LONGITUDE],
                    Collection::COLUMN_SERVICES_DOMESTIC => $rowData[Collection::COLUMN_SERVICES_DOMESTIC],
                    Collection::COLUMN_ACCESSIBLE_COUNTRIES => $countries,
                ];
            }

            // Keep going to check records for errors, even though they won't be inserted
            if ($terminated) {
                continue;
            }

            if ($entityList) {
                $this->_connection->insertOnDuplicate($tableName, $entityList, [
                    Collection::COLUMN_CODE,
                    Collection::COLUMN_NAME,
                    Collection::COLUMN_COUNTRY,
                    Collection::COLUMN_LATITUDE,
                    Collection::COLUMN_LONGITUDE,
                    Collection::COLUMN_SERVICES_DOMESTIC,
                    Collection::COLUMN_ACCESSIBLE_COUNTRIES,
                ]);
            }
        }

        if (!$terminated) {
            $this->_connection->delete($tableName, ["code NOT IN (?)" => $allCodes]);
        }
    }
}
