<?php
/**
 * @copyright Copyright (c) Aligent Consulting. (http://www.aligent.com.au)
 * @license https://opensource.org/licenses/osl-3.0.php OSL-3.0
 */

namespace EcoBahn\CarbonCalculator\Model;

use Magento\Framework\DataObject;
use EcoBahn\CarbonCalculator\Api\Data\CarbonCalculatorResultInterface;

class CarbonCalculatorResult extends DataObject implements CarbonCalculatorResultInterface
{
    // N.B. these methods need to be defined to implement the interface, but really they're magic,
    // implemented by \Magento\Framework\DataObject::__call
    // phpcs:disable Generic.CodeAnalysis.UselessOverridingMethod.Found
    public function getDistance(): ?float
    {
        return parent::getDistance();
    }

    public function getCarbonEmissions(): ?float
    {
        return parent::getCarbonEmissions();
    }
    // phpcs:enable
}
