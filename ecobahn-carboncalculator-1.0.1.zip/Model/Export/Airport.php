<?php
/**
 * @copyright Copyright (c) Aligent Consulting. (http://www.aligent.com.au)
 *            Includes code Copyright (c) Magento, Inc.
 * @license https://opensource.org/licenses/osl-3.0.php OSL-3.0
 */

namespace EcoBahn\CarbonCalculator\Model\Export;

use Magento\ImportExport\Model\Export;
use EcoBahn\CarbonCalculator\Model\ResourceModel\Airport\Collection as AirportCollection;
use EcoBahn\CarbonCalculator\Model\ResourceModel\Airport\CollectionFactory as AirportCollectionFactory;
use Magento\ImportExport\Model\Export\AbstractEntity;

class Airport extends AbstractEntity
{
    const ATTRIBUTE_COLLECTION_NAME = \EcoBahn\CarbonCalculator\Model\ResourceModel\Airport\Attribute\Collection::class;

    /** @var AirportCollection */
    protected $airportCollection;

    /** @var AirportCollectionFactory */
    protected $airportCollectionFactory;

    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\ImportExport\Model\Export\Factory $collectionFactory,
        \Magento\ImportExport\Model\ResourceModel\CollectionByPagesIteratorFactory $resourceColFactory,
        AirportCollectionFactory $airportCollectionFactory,
        array $data = []
    ) {
        $this->airportCollectionFactory = $airportCollectionFactory;
        parent::__construct($scopeConfig, $storeManager, $collectionFactory, $resourceColFactory, $data);
    }

    public function export()
    {
        $this->_prepareEntityCollection($this->_getEntityCollection());
        $writer = $this->getWriter();

        // create export file
        $writer->setHeaderCols($this->_getHeaderColumns());
        $this->_exportCollectionByPages($this->_getEntityCollection());

        return $writer->getContents();
    }

    public function exportItem($item)
    {
        $itemArr = $item->toArray();
        if (isset($itemArr['accessible_countries'])) {
            $itemArr['accessible_countries'] = trim($itemArr['accessible_countries'], ',');
        }
        $this->getWriter()->writeRow($itemArr);
    }

    public function getEntityTypeCode()
    {
        return 'ecobahn_airport';
    }

    protected function _getHeaderColumns()
    {
        return $this->_getExportAttributeCodes();
    }

    protected function _getEntityCollection($resetCollection = false)
    {
        if ($resetCollection || $this->airportCollection === null) {
            $this->airportCollection = $this->airportCollectionFactory->create();
        }
        return $this->airportCollection;
    }

    /**
     * Apply filter to collection and add not skipped attributes to select
     *
     * @param AirportCollection $collection
     * @return AirportCollection
     */
    protected function _prepareEntityCollection(AirportCollection $collection)
    {
        $this->filterEntityCollection($collection);
        $this->_addAttributesToCollection($collection);
        return $collection;
    }

    public function filterEntityCollection(AirportCollection $collection)
    {
        if (!isset($this->_parameters[Export::FILTER_ELEMENT_GROUP])
            || !is_array($this->_parameters[Export::FILTER_ELEMENT_GROUP])
        ) {
            return $collection;
        }
        $exportFilter = $this->_parameters[Export::FILTER_ELEMENT_GROUP];

        foreach ($this->filterAttributeCollection($this->getAttributeCollection()) as $attribute) {
            $attributeCode = $attribute->getAttributeCode();
            if (!isset($exportFilter[$attributeCode])) {
                continue;
            }

            // filter applying
            $attributeFilterType = Export::getAttributeFilterType($attribute);
            if (Export::FILTER_TYPE_SELECT == $attributeFilterType) {
                if (is_scalar($exportFilter[$attributeCode]) && trim($exportFilter[$attributeCode])) {
                    $collection->addFieldToFilter(
                        $attributeCode,
                        ['eq' => $exportFilter[$attributeCode]]
                    );
                }
            } elseif (Export::FILTER_TYPE_MULTISELECT == $attributeFilterType) {
                if (is_array($exportFilter[$attributeCode])) {
                    array_filter($exportFilter[$attributeCode]);
                    if (!empty($exportFilter[$attributeCode])) {
                        foreach ($exportFilter[$attributeCode] as $val) {
                            $collection->addFieldToFilter(
                                $attributeCode,
                                ['finset' => $val]
                            );
                        }
                    }
                }
            } elseif (Export::FILTER_TYPE_INPUT == $attributeFilterType) {
                if (is_scalar($exportFilter[$attributeCode]) && trim($exportFilter[$attributeCode])) {
                    $collection->addFieldToFilter(
                        $attributeCode,
                        ['like' => "%{$exportFilter[$attributeCode]}%"]
                    );
                }
            } elseif (Export::FILTER_TYPE_DATE == $attributeFilterType) {
                if (is_array($exportFilter[$attributeCode]) && count($exportFilter[$attributeCode]) == 2) {
                    $from = array_shift($exportFilter[$attributeCode]);
                    $to = array_shift($exportFilter[$attributeCode]);

                    if (is_scalar($from) && !empty($from)) {
                        $date = (new \DateTime($from))->format('m/d/Y');
                        $collection->addFieldToFilter($attributeCode, ['from' => $date, 'date' => true]);
                    }
                    if (is_scalar($to) && !empty($to)) {
                        $date = (new \DateTime($to))->format('m/d/Y');
                        $collection->addFieldToFilter($attributeCode, ['to' => $date, 'date' => true]);
                    }
                }
            } elseif (Export::FILTER_TYPE_NUMBER == $attributeFilterType) {
                if (is_array($exportFilter[$attributeCode]) && count($exportFilter[$attributeCode]) == 2) {
                    $from = array_shift($exportFilter[$attributeCode]);
                    $to = array_shift($exportFilter[$attributeCode]);

                    if (is_numeric($from)) {
                        $collection->addFieldToFilter($attributeCode, ['from' => $from]);
                    }
                    if (is_numeric($to)) {
                        $collection->addFieldToFilter($attributeCode, ['to' => $to]);
                    }
                }
            }
        }
        return $collection;
    }

    protected function _addAttributesToCollection(AirportCollection $collection)
    {
        $attributeCodes = $this->_getExportAttributeCodes();
        $collection->addFieldToSelect($attributeCodes);
        return $collection;
    }
}
