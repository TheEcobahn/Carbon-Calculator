<?php
/**
 * @copyright Copyright (c) Aligent Consulting. (http://www.aligent.com.au)
 * @license https://opensource.org/licenses/osl-3.0.php OSL-3.0
 */

namespace EcoBahn\CarbonCalculator\Model;

use Magento\Framework\DataObject\IdentityInterface;
use Magento\Framework\Model\AbstractModel;
use Magento\Framework\Registry;
use Magento\Framework\Model\Context;
use Magento\Framework\Model\ResourceModel\AbstractResource;
use Magento\Framework\Data\Collection\AbstractDb;
use EcoBahn\CarbonCalculator\Api\Data\GeoCoordinateInterfaceFactory;
use EcoBahn\CarbonCalculator\Api\Data\GeoCoordinateInterface;

class Airport extends AbstractModel implements IdentityInterface
{
    const CACHE_TAG = 'ecobahn_airport';

    /** @var GeoCoordinateInterfaceFactory */
    private $coordinateFactory;

    public function __construct(
        Context $context,
        Registry $registry,
        GeoCoordinateInterfaceFactory $coordinateFactory,
        AbstractResource $resource = null,
        AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
        if (empty($data)) {
            $this->_isObjectNew = true;
        }
        $this->coordinateFactory = $coordinateFactory;
    }

    /**
     * Initialize resources
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(ResourceModel\Airport::class);
    }

    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    public function getCoordinates(): GeoCoordinateInterface
    {
        return $this->coordinateFactory->create([
            'latitude' => $this->getLat(),
            'longitude' => $this->getLng(),
        ]);
    }
}
