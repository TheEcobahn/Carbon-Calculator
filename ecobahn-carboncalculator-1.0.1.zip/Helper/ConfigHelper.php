<?php
/**
 * @copyright Copyright (c) Aligent Consulting. (http://www.aligent.com.au)
 * @license https://opensource.org/licenses/osl-3.0.php OSL-3.0
 */

namespace EcoBahn\CarbonCalculator\Helper;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Config\Storage\WriterInterface;
use Magento\Directory\Model\RegionFactory;
use Magento\Directory\Model\ResourceModel\Region as RegionResource;
use EcoBahn\CarbonCalculator\Model\WarehouseAddress;
use EcoBahn\CarbonCalculator\Model\WarehouseAddressFactory;
use EcoBahn\CarbonCalculator\Api\Data\GeoCoordinateInterface;
use EcoBahn\CarbonCalculator\Api\Data\GeoCoordinateInterfaceFactory;

class ConfigHelper
{
    const GEOCODE_API_URL = 'https://maps.googleapis.com/maps/api/geocode/';
    const GEOCODE_API_CONVERT = 'json';
    const GEOCODE_RESPONSE_STATUS = 200;

    const XML_PATH_GOOGLE_API_KEY = 'ecobahn_carbon_calc/geocode_settings/google_api_key';
    const XML_PATH_WAREHOUSE_LAT = 'ecobahn_carbon_calc/warehouse/latitude';
    const XML_PATH_WAREHOUSE_LNG = 'ecobahn_carbon_calc/warehouse/longitude';
    const XML_PATH_WAREHOUSE_AIRPORT = 'ecobahn_carbon_calc/warehouse/airport';
    const XML_PATH_WAREHOUSE_AIRPORT_DIST = 'ecobahn_carbon_calc/warehouse/airport_distance';
    const XML_PATH_EMISSIONS_ROAD = 'ecobahn_carbon_calc/transport/emissions_road';
    const XML_PATH_EMISSIONS_AIR = 'ecobahn_carbon_calc/transport/emissions_air';

    const XML_PATH_WAREHOUSE_STREET1 = 'general/store_information/street_line1';
    const XML_PATH_WAREHOUSE_STREET2 = 'general/store_information/street_line2';
    const XML_PATH_WAREHOUSE_CITY = 'general/store_information/city';
    const XML_PATH_WAREHOUSE_REGION = 'general/store_information/region_id';
    const XML_PATH_WAREHOUSE_POSTCODE = 'general/store_information/postcode';
    const XML_PATH_WAREHOUSE_COUNTRY = 'general/store_information/country_id';

    const SALES_SHIPMENT_CARBON_EMISSIONS_FIELD = 'carbon_emissions';
    const SALES_SHIPMENT_DISTANCE_FIELD = 'carbon_distance';

    // Emissions rate: CO2 per km per kg
    const EMISSIONS_RATE_ROAD = 0.00008;
    const EMISSIONS_RATE_AIR  = 0.00120;

    /**
     * @var ScopeConfigInterface
     */
    private $scopeConfig;

    /**
     * @var WriterInterface
     */
    private $configWriter;

    /**
     * @var ExtensibleDataInterfaceFactory
     */
    private $addressFactory;

    /**
     * @var RegionFactory
     */
    private $regionFactory;

    /**
     * @var RegionResource
     */
    private $regionResource;

    /**
     * @param ScopeConfigInterface $scopeConfig
     * @param WriterInterface $configWriter
     * @param WarehouseAddressFactory $warehouseAddressFactory
     * @param GeoCoordinateInterfaceFactory $coordinateFactory
     * @param RegionFactory $regionFactory
     * @param RegionResource $regionResource
     */
    public function __construct(
        ScopeConfigInterface $scopeConfig,
        WriterInterface $configWriter,
        WarehouseAddressFactory $warehouseAddressFactory,
        GeoCoordinateInterfaceFactory $coordinateFactory,
        RegionFactory $regionFactory,
        RegionResource $regionResource
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->configWriter = $configWriter;
        $this->warehouseAddressFactory = $warehouseAddressFactory;
        $this->coordinateFactory = $coordinateFactory;
        $this->regionFactory = $regionFactory;
        $this->regionResource = $regionResource;
    }

    public function clean()
    {
        // N.B. clean function exists in \Magento\Framework\App\Config but not in ScopeConfigInterface
        if (method_exists($this->scopeConfig, 'clean')) {
            $this->scopeConfig->clean();
        }
    }

    public function getWarehouseLat()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_WAREHOUSE_LAT, 'stores');
    }

    public function getWarehouseLng()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_WAREHOUSE_LNG, 'stores');
    }

    public function getWarehouseCoords(): ?GeoCoordinateInterface
    {
        $lat = $this->getWarehouseLat();
        $lng = $this->getWarehouseLng();
        if ($lat !== null && $lng !== null) {
            return $this->coordinateFactory->create(
                [
                    'latitude' => $lat,
                    'longitude' => $lng,
                ]
            );
        }
        return null;
    }

    public function setWarehouseLat(float $latitude)
    {
        return $this->configWriter->save(self::XML_PATH_WAREHOUSE_LAT, $latitude);
    }

    public function setWarehouseLng(float $longitude)
    {
        return $this->configWriter->save(self::XML_PATH_WAREHOUSE_LNG, $longitude);
    }

    public function getWarehouseCountry()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_WAREHOUSE_COUNTRY, 'stores');
    }

    public function getWarehouseAirportCode()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_WAREHOUSE_AIRPORT, 'stores');
    }

    public function getWarehouseAirportDistance()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_WAREHOUSE_AIRPORT_DIST, 'stores');
    }

    public function setWarehouseAirport(\EcoBahn\CarbonCalculator\Model\Airport $airport)
    {
        return $this->configWriter->save(self::XML_PATH_WAREHOUSE_AIRPORT, $airport->getCode());
    }

    public function setWarehouseAirportDistance(float $distance)
    {
        return $this->configWriter->save(self::XML_PATH_WAREHOUSE_AIRPORT_DIST, $distance);
    }

    public function getRoadEmissions()
    {
        return static::EMISSIONS_RATE_ROAD;
    }

    public function getAirEmissions()
    {
        return static::EMISSIONS_RATE_AIR;
    }

    public function getGeocodeApiKey()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_GOOGLE_API_KEY, 'stores');
    }

    public function getGeoCodeApiUrl()
    {
        return self::GEOCODE_API_URL . self::GEOCODE_API_CONVERT;
    }

    public function getWarehouseAddress(): WarehouseAddress
    {
        /**
         * @var WarehouseAddress $address
         */
        $address = $this->warehouseAddressFactory->create();
        $street = array_filter(
            [
                $this->scopeConfig->getValue(self::XML_PATH_WAREHOUSE_STREET1, 'stores'),
                $this->scopeConfig->getValue(self::XML_PATH_WAREHOUSE_STREET2, 'stores'),
            ]
        );
        $address->setStreet($street);
        $address->setCity($this->scopeConfig->getValue(self::XML_PATH_WAREHOUSE_CITY, 'stores'));

        $regionId = $this->scopeConfig->getValue(self::XML_PATH_WAREHOUSE_REGION, 'stores');
        if ($regionId) {
            $region = $this->regionFactory->create();
            $this->regionResource->load($region, $regionId);
            $address->setRegion($region);
            $address->setRegionCode($region->getCode());
        }

        $address->setPostcode($this->scopeConfig->getValue(self::XML_PATH_WAREHOUSE_POSTCODE, 'stores'));
        $address->setCountryId($this->getWarehouseCountry());

        return $address;
    }
}
