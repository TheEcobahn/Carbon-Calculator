# EcoBahn Carbon Calculator

A module for estimating carbon emissions for shipments made from Magento 2 stores.


## Installation

Install via `composer` or copy the code into `app/code/EcoBahn/CabonCalculator`, so this file sits at `app/code/EcoBahn/CabonCalculator/README.md`.

Full step-by-step guide for installation via Composer can be viewed at https://devdocs.magento.com/extensions/install/


## Initial Configuration

Once the EcoBahn Carbon Calculator has been installed, there are 3 required configuration steps to complete installation. Once all three of these configuration steps have been completed, a refresh of the configuration cache should be completed via `System > Tools > Cache Management`. The EcoBahn Carbon Calculator will then automatically begin processing carbon emission data for your orders.

### 1. Google Maps API

The Google Maps API is used for all road freight calculations, and for automatically determining the warehouse co-ordinates if they haven't been entered. Specifically, the system uses the Distance Matrix and Geocoding APIs.

To access the Google Maps API, you must sign-up for an account at https://developers.google.com/maps/documentation/geocoding/get-api-key

Please note: During the sign-up for a Google Maps API account, you will be required to add billing details. The API is free to use for up to 40,000 requests per month, with a single request required to calculate the carbon footprint for a single order. The API is therefore free to use for all eCommerce stores processing less the 40,000 orders per month.

Once you have your Google Maps API key, please enter the API key to the Magento Admin at `Admin > Stores > Settings > Configuration > EcoBahn > Carbon Calculator`

The other fields shown at `Admin > Stores > Settings > Configuration > EcoBahn > Carbon Calculator` can be left blank (Latitude, Longitude, Closest Airport, Distance to Airport).  These will be automatically determined following configuration.

### 2. Warehouse Address

Distances are calculated based on the warehouse location. The location of your warehouse is a prerequisite before distances, and therefore carbon emissions, can be calculated.

The warehouse location should be fully completed under the ‘Store Information’ section:  
`Admin > Stores > Settings > Configuration > General > General > Store Information`

### 3. KG as Default Weight Unit

The module calculates the value of CO2 per km, per kg package weight for its estimations.

Note that because kilograms and kilometres are used, Magento needs to be configured to use kgs as its default weight unit. This can be done via `Admin > Stores > Settings > Configuration > General > General > Locale Options > Weight Unit`


## Advanced Configuration

### Airport list

The EcoBahn Carbon Calculator module estimates the carbon emissions based on road and air traffic.

For short distances between the warehouse and the customer, the system calculates emissions based on road freight.

For longer distances, the system treats shipments as if they first go via road from the warehouse to its nearest airport, secondly from there to the airport nearest to the customer via air, and thirdly via road to the customer.

As part of the module installation, the list of airport data will be automatically configured.

You do however have the option to modify the Airport List by exporting it as a CSV file, making changes, then reimporting, via `System > Data Transfer > Import/Export`. In order to prevent the system from calculating air freight for short distances, only a single airport per city should be included.

The Ecobahn Carbon Calculator uses complex algorithms and has been designed to provide an accurate estimate on the logistics route of a parcel so amending the Airport List is not recommended. A specific use case however would be for customers with a detailed knowledge of the logistics network for a provider in a given country, and therefore only want to utilise specific airports for increased accuracy.


### Manual Edit Initial Configuration

As noted previously, key details such as the closest airport to the warehouse and the distance to that airport are automatically determined as part of the calculation of the very first emissions calculation performed. They can also be entered manually via
`Admin > Stores > Settings > Configuration > EcoBahn > Carbon Calculator`


## Reporting

The reports on daily carbon emissions can be found via
`Admin > Reports > Sales > Carbon Emissions`

These can be exported to a CSV or MS Excel XML file for deeper analysis, graphing etc.

### Reporting Logic

90-Day Calculation- Once configured, the EcoBahn Carbon Calculator will collect carbon emission data for all orders in the last 90 days.

Future Orders- After this initial 90-day calculation, the EcoBahn Carbon Calculator will automatically calculate carbon emissions for every future order placed. This will happen through a cron job checking for newly placed orders.
