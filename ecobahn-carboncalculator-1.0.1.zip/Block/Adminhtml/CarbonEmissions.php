<?php
/**
 * @copyright Copyright (c) Aligent Consulting. (http://www.aligent.com.au)
 * @license https://opensource.org/licenses/osl-3.0.php OSL-3.0
 */

namespace EcoBahn\CarbonCalculator\Block\Adminhtml;

class CarbonEmissions extends \Magento\Backend\Block\Widget\Grid\Container
{
    /**
     * Template
     *
     * @var string
     */
    protected $_template = 'Magento_Reports::report/grid/container.phtml';

    /**
     * {@inheritdoc}
     */
    protected function _construct()
    {
        $this->_blockGroup = 'EcoBahn_CarbonCalculator';
        $this->_controller = 'adminhtml_report_emissions';
        $this->_headerText = __('Carbon Emissions Report');
        parent::_construct();

        $this->buttonList->remove('add');
        $this->addButton(
            'filter_form_submit',
            ['label' => __('Show Report'), 'onclick' => 'filterFormSubmit()', 'class' => 'primary']
        );
    }

    public function getGridHtml()
    {
        $gridHtml = parent::getGridHtml();

        /** @var \Magento\Framework\View\LayoutInterface $layout */
        $layout = $this->getLayout();
        $gridName = $layout->getChildName($this->getNameInLayout(), 'grid');

        /** @var \EcoBahn\CarbonCalculator\Block\Adminhtml\Report\Emissions\Grid $grid */
        $grid = $layout->getBlock($gridName);

        // Pass loaded grid data to graph block
        if ($grid) {
            $graphLabels = [];
            $graphValues = [];
            foreach ($grid->getCollection() as $period => $item) {
                $graphLabels[] = $period;
                $periodEmissions = $item->getData('carbon_emissions_total');
                $children = $item->getChildren();
                foreach ($children as $child) {
                    $periodEmissions += $child->getData('carbon_emissions_total');
                }
                $graphValues[] = $periodEmissions;
            }

            /** @var \Magento\Backend\Block\Template $emissionsGraph */
            $emissionsGraph = $layout->getBlock('emissions-graph');
            $emissionsGraph->setGraphLabels($graphLabels);
            $emissionsGraph->setGraphValues($graphValues);
        }

        return $this->getChildHtml('emissions-graph') . $gridHtml;
    }

    /**
     * Get filter URL
     *
     * @return string
     */
    public function getFilterUrl()
    {
        $this->getRequest()->setParam('filter', null);
        return $this->getUrl('*/*/emissions', ['_current' => true]);
    }
}
