<?php
/**
 * @copyright Copyright (c) Aligent Consulting. (http://www.aligent.com.au)
 *            Includes code Copyright (c) Magento, Inc.
 * @license https://opensource.org/licenses/osl-3.0.php OSL-3.0
 */

namespace EcoBahn\CarbonCalculator\Block\Adminhtml\Report\Emissions;

/**
 * Based on \Magento\Reports\Block\Adminhtml\Sales\Bestsellers\Grid
 */
class Grid extends \Magento\Reports\Block\Adminhtml\Grid\AbstractGrid
{
    /**
     * GROUP BY criteria
     *
     * @var string
     */
    protected $_columnGroupBy = 'period';

    /**
     * {@inheritdoc}
     * @codeCoverageIgnore
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setCountTotals(true);
    }

    /**
     * {@inheritdoc}
     * @codeCoverageIgnore
     */
    public function getResourceCollectionName()
    {
        return \EcoBahn\CarbonCalculator\Model\ResourceModel\Report\Emissions\Collection::class;
    }

    /**
     * {@inheritdoc}
     */
    protected function _prepareColumns()
    {
        $this->addColumn(
            'period',
            [
                'header' => __('Interval'),
                'index' => 'period',
                'sortable' => false,
                'period_type' => $this->getPeriodType(),
                'renderer' => \Magento\Reports\Block\Adminhtml\Sales\Grid\Column\Renderer\Date::class,
                'totals_label' => __('Total'),
                'html_decorators' => ['nobr'],
                'header_css_class' => 'col-period',
                'column_css_class' => 'col-period'
            ]
        );

        // Should be \Magento\Framework\DataObject
        if ($this->getFilterData()->getStoreIds()) {
            $this->setStoreIds(explode(',', $this->getFilterData()->getStoreIds()));
        }
        $currencyCode = $this->getCurrentCurrencyCode();

        $this->addColumn(
            'shipping_country',
            [
                'header' => __('Country'),
                'index' => 'shipping_country',
                'type' => 'country',
                'sortable' => false,
                'header_css_class' => 'col-country',
                'column_css_class' => 'col-country',
            ]
        );

        $this->addColumn(
            'carbon_emissions_total',
            [
                'header' => __('Emissions (kg)'),
                'index' => 'carbon_emissions_total',
                'type' => 'number',
                'total' => 'sum',
                'sortable' => false,
                'header_css_class' => 'col-price',
                'column_css_class' => 'col-price'
            ]
        );
        $this->addColumn(
            'carbon_distance_total',
            [
                'header' => __('Distance transported (km)'),
                'index' => 'carbon_distance_total',
                'type' => 'number',
                'total' => 'sum',
                'sortable' => false,
                'header_css_class' => 'col-price',
                'column_css_class' => 'col-price'
            ]
        );

        $this->addColumn(
            'carbon_emissions_offset',
            [
                'header' => __('Emissions offset'),
                'index' => 'carbon_emissions_offset',
                'type' => 'number',
                'total' => 'sum',
                'sortable' => false,
                'header_css_class' => 'col-price',
                'column_css_class' => 'col-price'
            ]
        );

        $this->addColumn(
            'carbon_price_total',
            [
                'header' => __('Carbon price'),
                'index' => 'carbon_price_total',
                'type' => 'number',
                'total' => 'sum',
                'sortable' => false,
                'header_css_class' => 'col-price',
                'column_css_class' => 'col-price'
            ]
        );

        $this->addColumn(
            'carbon_price_paid',
            [
                'header' => __('Paid'),
                'index' => 'carbon_price_paid',
                'type' => 'number',
                'total' => 'sum',
                'sortable' => false,
                'header_css_class' => 'col-price',
                'column_css_class' => 'col-price'
            ]
        );

        $this->addExportType('*/*/exportEmissionsCsv', __('CSV'));
        $this->addExportType('*/*/exportEmissionsExcel', __('Excel XML'));

        return parent::_prepareColumns();
    }
}
