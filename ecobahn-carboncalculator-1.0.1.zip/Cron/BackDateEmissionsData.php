<?php
/**
 * @copyright Copyright (c) Aligent Consulting. (http://www.aligent.com.au)
 * @license https://opensource.org/licenses/osl-3.0.php OSL-3.0
 */

namespace EcoBahn\CarbonCalculator\Cron;

use Psr\Log\LoggerInterface;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Sales\Api\Data\ShipmentInterface;
use Magento\Sales\Api\ShipmentRepositoryInterface;
use Magento\Sales\Model\ResourceModel\Order\Shipment\CollectionFactory;
use Magento\Sales\Model\ResourceModel\Order\Shipment\Collection as ShipmentCollection;
use EcoBahn\CarbonCalculator\Api\CarbonCalculatorInterfaceFactory;
use EcoBahn\CarbonCalculator\Helper\ConfigHelper;
use EcoBahn\CarbonCalculator\Model\ResourceModel\Report\CarbonEmissionFactory as ReportFactory;

class BackDateEmissionsData
{
    /** @var string Duration back to earliest/oldest shipment creation date of old orders to fetch */
    const EARLIEST_CREATION = 'P90D';

    /** @var string Duration back to latest/newest shipment creation date for deciding to calculate emissions */
    const LATEST_CREATION = 'PT10M';

    const DATETIME_FORMAT = 'Y-m-d H:i:s';

    /** @var LoggerInterface */
    private $logger;

    /** @var TimezoneInterface */
    private $timezone;

    /** @var ShipmentRepositoryInterface */
    private $shipmentRepository;

    /** @var CollectionFactory */
    private $shipmentCollectionFactory;

    public function __construct(
        LoggerInterface $logger,
        TimezoneInterface $timezone,
        ShipmentRepositoryInterface $shipmentRepository,
        CollectionFactory $shipmentCollectionFactory,
        ReportFactory $reportFactory
    ) {
        $this->logger = $logger;
        $this->timezone = $timezone;
        $this->shipmentRepository = $shipmentRepository;
        $this->shipmentCollectionFactory = $shipmentCollectionFactory;
        $this->reportFactory = $reportFactory;
    }

    public function execute()
    {
        // Only backdate calculation if there are no existing shipments with emissions data
        $existingShipment = $this->getExistingShipment();
        if ($existingShipment->getEntityId()) {
            return;
        }

        $earliest = $this->timezone->date();
        $earliest->setTime(0, 0, 0);
        $earliest->sub(new \DateInterval(self::EARLIEST_CREATION));
        $shipments = $this->getCalculableShipments($earliest);
        $firstShipment = true;
        foreach ($shipments as $shipment) {
            $this->shipmentRepository->save($shipment);

            // If configuration isn't complete or correct, emissions calculation will fail
            // In such a case, exit immediately instead of trying again for each remaining order
            if ($firstShipment) {
                $firstShipment = false;
                if ($shipment->getData(ConfigHelper::SALES_SHIPMENT_CARBON_EMISSIONS_FIELD) === null) {
                    $this->logger->warning(__('First backlog emission calculation failed; check config'));
                    return;
                }
            }
        }

        $this->aggregateShipments($earliest);
    }

    public function getExistingShipment(): ?ShipmentInterface
    {
        /** @var ShipmentCollection $shipments */
        $shipments = $this->shipmentCollectionFactory->create();
        $shipments->setPageSize(1);
        $shipments->addFieldToFilter(ConfigHelper::SALES_SHIPMENT_CARBON_EMISSIONS_FIELD, ['notnull' => true]);

        $utc = new \DateTimeZone('UTC');

        /** @var \DateTime $earliest */
        $earliest = $this->timezone->date()->sub(new \DateInterval(self::EARLIEST_CREATION));
        $shipments->addFieldToFilter(
            ShipmentInterface::CREATED_AT,
            ['gteq' => $earliest->setTimezone($utc)->format(self::DATETIME_FORMAT)]
        );

        /** @var \DateTime $latest */
        $latest = $this->timezone->date()->sub(new \DateInterval(self::LATEST_CREATION));
        $shipments->addFieldToFilter(
            ShipmentInterface::CREATED_AT,
            ['lt' => $latest->setTimezone($utc)->format(self::DATETIME_FORMAT)]
        );

        return $shipments->getFirstItem();
    }

    public function getCalculableShipments($earliest): ShipmentCollection
    {
        $shipments = $this->shipmentCollectionFactory->create();
        $shipments->addFieldToFilter(ConfigHelper::SALES_SHIPMENT_CARBON_EMISSIONS_FIELD, ['null' => true]);
        $shipments->addFieldToFilter(
            ShipmentInterface::CREATED_AT,
            ['gteq' => $earliest->setTimezone(new \DateTimeZone('UTC'))->format(self::DATETIME_FORMAT)]
        );
        return $shipments;
    }

    public function aggregateShipments($fromDate)
    {
        /** @var \EcoBahn\CarbonCalculator\Model\ResourceModel\Report\CarbonEmission $report */
        $report = $this->reportFactory->create();
        $report->aggregate($fromDate, $this->timezone->date());
    }
}
