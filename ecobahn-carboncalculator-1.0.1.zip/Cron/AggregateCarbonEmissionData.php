<?php
/**
 * @copyright Copyright (c) Aligent Consulting. (http://www.aligent.com.au)
 * @license https://opensource.org/licenses/osl-3.0.php OSL-3.0
 */

namespace EcoBahn\CarbonCalculator\Cron;

use DateInterval;
use EcoBahn\CarbonCalculator\Model\ResourceModel\Report\CarbonEmissionFactory;
use Exception;
use Magento\Framework\Locale\ResolverInterface;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;

class AggregateCarbonEmissionData
{
    /**
     * @var ResolverInterface
     */
    private $localeResolver;

    /**
     * @var TimezoneInterface
     */
    private $localeDate;

    /**
     * @var CarbonEmissionFactory
     */
    private $carbonEmissionFactory;

    /**
     * @param ResolverInterface $localeResolver
     * @param TimezoneInterface $timezone
     * @param CarbonEmissionFactory $carbonEmissionFactory
     */
    public function __construct(
        ResolverInterface $localeResolver,
        TimezoneInterface $timezone,
        CarbonEmissionFactory $carbonEmissionFactory
    ) {
        $this->localeResolver = $localeResolver;
        $this->localeDate = $timezone;
        $this->carbonEmissionFactory = $carbonEmissionFactory;
    }

    /**
     * Refresh carbon emissions report statistics for last day
     *
     * @return void
     * @throws Exception
     */
    public function execute()
    {
        $this->localeResolver->emulate(0);
        $currentDate = $this->localeDate->date();
        $fromDate = $currentDate->sub(new DateInterval('PT25H'));
        /** @var \EcoBahn\CarbonCalculator\Model\ResourceModel\Report\CarbonEmission $report */
        $report = $this->carbonEmissionFactory->create();
        $report->aggregate($fromDate, $this->localeDate->date());
        $this->localeResolver->revert();
    }
}
